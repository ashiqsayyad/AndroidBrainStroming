package com.ashsample.androidconcepts;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import com.ashsample.androidconcepts.recycleviews.pojos.MainRecycleViewAdapter;
import com.ashsample.androidconcepts.recycleviews.pojos.MainRecycleViewItem;
import com.ashsample.androidconcepts.recycleviews.pojos.MainRecycleViewItemsGenerator;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private ArrayList<MainRecycleViewItem> listitems;
    RecyclerView.Adapter mainRecycleViewAdapter;
    RecyclerView.LayoutManager mainRecycleViewLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                tryMaps();
            }
        });
        initMainRecylceView();
        tryMaps();


    }
     public void tryMaps(){
        ArrayMap<String, String> temp = new ArrayMap<>();
         temp.put("second","tiger");
        temp.put("first","zebra");
        temp.put("thrid","deer");

         HashMap<String, String> temp1 = new HashMap<>();
         temp1.put("second","tiger");
         temp1.put("first","zebra");
         temp1.put("thrid","deer");



    }

    public void initMainRecylceView(){
       listitems = MainRecycleViewItemsGenerator.getInstance().getListitems();
        mainRecycleViewAdapter = new MainRecycleViewAdapter(listitems);
        mainRecycleViewLayoutManager =new LinearLayoutManager(this, OrientationHelper.VERTICAL, false);
        RecyclerView mainRecycleView = findViewById(R.id.mainrecycleview);
        mainRecycleView.setAdapter(mainRecycleViewAdapter);
        mainRecycleView.setLayoutManager(mainRecycleViewLayoutManager);

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("Ashiq","pppppppppppppppppp");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
