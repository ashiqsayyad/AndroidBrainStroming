package com.ashsample.androidconcepts.mvvm.room;

public class NoteEntity {
}
